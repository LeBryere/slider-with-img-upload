NOTE: This demo font is for PERSONAL USE ONLY! But any donation are very appreciated.
Paypal account for donation : https://paypal.me/khaiuns

Link to purchase full version and commercial license:
https://www.myfonts.com/fonts/khaiuns/lovtony/

And follow my Behance for update: https://www.behance.net/khairunnas2308

Thank you